' RANDOM NUMBERS GENERATOR

On Error Resume Next
Title("Random numbers generator")
Do
    Clear
    Write("How many numbers to generate? (""/end"" for exit) >> ") : CycleTickBefore = Input
    If (CycleTickBefore = "/end") Then
        Close
    End If
    Write("Minimum >> ") : Min = Input 
    Write("Maximum >> ") : Max = Input 
    For i = 1 To CycleTickBefore
        WriteLine("(" & i & "/" & CycleTickBefore & "). Random number beetwen " & Min & " and " & Max & " - " & Random(Min, Max))
    Next
    If Exception Then
        WriteLine("Input error")
    End If
    Input
Loop